#!/bin/bash

echo "开始运行"
/usr/local/bin/python /xuexi/pandalearning.py
